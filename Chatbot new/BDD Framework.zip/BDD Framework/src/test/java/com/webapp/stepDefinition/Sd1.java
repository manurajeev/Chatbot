package com.webapp.stepDefinition;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.webapp.baseLibrary.FunctionsLibrary;
import com.webapp.baseLibrary.VerificationFunctions;
import com.webapp.page.HomePage;
import com.webapp.utilities.GridReporter;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Sd1 {
	FunctionsLibrary functions = new FunctionsLibrary();
	HomePage homePage = new HomePage();
	public String tc_id = CommonStepDefinitions.tc_id;
	public String scenarioName = CommonStepDefinitions.scenarioName;
	VerificationFunctions verificationFunctions = new VerificationFunctions();
	public Map<String, String> testData = CommonStepDefinitions.testData;
	public String strReportFilename = "";
	static GridReporter reporter = CommonStepDefinitions.getReporter();
	WebDriverWait wait = new WebDriverWait(FunctionsLibrary.driver, 60);

	@And("^Verify \"([^\"]*)\" data in the home$")
	public void verify_data_in_home(String channel) {
		if (!CommonStepDefinitions.executeScenario) {
			return;
		}
	}
}
